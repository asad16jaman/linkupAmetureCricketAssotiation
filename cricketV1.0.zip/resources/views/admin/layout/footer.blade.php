<footer class="footer">
  <div class="container-fluid d-flex justify-content-end">
    <div class="copyright">
      Designed & Developed by
      <a href="https://linktechbd.com/">Link Up Technology</a>
    </div>
  </div>
</footer>