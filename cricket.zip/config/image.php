<?php

return [

    'driver' => 'gd'

];
