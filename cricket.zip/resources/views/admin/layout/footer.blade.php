<footer class="footer">
          <div class="container-fluid d-flex justify-content-between">
            
            <div class="copyright">
              2025, made  <i class="fa fa-heart heart text-danger"></i> by
              <a href="https://linktechbd.com/">{{ $company ? $company->name : "Link Up Technology" }}</a>
            </div>
            <div>
              .
            </div>
          </div>
        </footer>