

<?php $__env->startSection('title'); ?>
    Cricket Association | Chairman Message
<?php $__env->stopSection(); ?>



<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <section class="banner-part sub-main-banner float-start w-100">
        <div class="baner-imghi">
            <img src="<?php echo e(asset('frontend/images/sub-banner01.jpg')); ?>" alt="sub-banner">
        </div>
        <div class="sub-banner">
            <div class="container">
                <h1 class="text-center"> <?php echo e(optional($auth_message)->designation ? optional($auth_message)->designation : "Chairman"); ?> Message</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb justify-content-center">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li class="breadcrumb-item-"></li>
                    </ol>
                </nav>
            </div>
        </div>
    </section>

    <div class="about-page-main comon-sub-page-main d-inline-block w-100">
        <div class="about-club-top mt-3">
            <div class="container pb-1 pt-0">
                <div class="row row-cols-1 row-cols-lg-2 g-lg-5 py-5">
                    <div class="col" >
                        <figure class="big-img">
                            <img style="object-fit: contain;!important" src="<?php echo e(asset('storage/'.$auth_message->img)); ?>" alt="pic">
                        </figure>
                    </div>
                    <div class="col">
                        <h5 class="mb-1 mt-0"><?php echo e(optional($auth_message)->name); ?> </h5>
                        <small class="comon-heading- m-0"> <?php echo e(optional($auth_message)->designation); ?> </small>
                        <p><?php echo optional($auth_message)->speech; ?></p>

                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\cricket\resources\views/frontend/welcome/messageDetails.blade.php ENDPATH**/ ?>