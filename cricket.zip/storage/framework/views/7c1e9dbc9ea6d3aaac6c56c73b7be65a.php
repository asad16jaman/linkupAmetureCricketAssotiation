

<?php $__env->startPush('css'); ?>
    <style>
        .player-card .card {
            border: 1px solid #C40E00 !important;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .player-card:hover .card {
            transform: translateY(-6px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }

        /* Social Icons Overlay */
        .social-icons {
            position: absolute;
            bottom: 15px;
            left: 50%;
            transform: translateX(-50%);
            opacity: 0;
            transition: 0.4s ease;
            gap: 10px;
        }

        .player-card:hover .social-icons {
            opacity: 1;
        }

        .btn-social {
            background: #C40E00;
            color: #fff;
            border-radius: 50%;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: 0.3s ease;
        }

        .btn-social:hover {
            background: #900b00;
            transform: scale(1.1);
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('title'); ?>
    Cricket Association | All Blogs
<?php $__env->stopSection(); ?>



<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <section class="banner-part sub-main-banner float-start w-100">
        <div class="baner-imghi">
            <img src="<?php echo e(asset('frontend/images/sub-banner01.jpg')); ?>" alt="sub-banner">
        </div>
        <div class="sub-banner">
            <div class="container">
                <h1 class="text-center">Team Members</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb justify-content-center">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li class="breadcrumb-item-"></li>
                    </ol>
                </nav>
            </div>
        </div>
    </section>

    <div class="container">
        <div class="container">
            <div class="row g-4 mt-0 mb-3 py-3">
                <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-2 col-sm-4">
                        <div class="player-card">
                            <div class="card border">
                                <div class="position-relative">
                                    <img style="height:170px" src="<?php echo e(asset('storage/' . $player->photo)); ?>" class="card-img-top"
                                        alt="<?php echo e($player->name); ?>">
                                    <ul class="social-icons list-unstyled d-flex justify-content-center">
                                        <li><a href="#" class="btn btn-social"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#" class="btn btn-social"><i class="fab fa-linkedin-in"></i></a></li>
                                    </ul>
                                </div>
                                <div class="card-body text-center">
                                    <a href="" data-discover="true">
                                        <h5 class="card-title mb-1"><?php echo e($player->name); ?></h5>
                                    </a>
                                    <p class="text-muted mb-0"><?php echo e($player->designation); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\cricket\resources\views/frontend/welcome/teamMembers.blade.php ENDPATH**/ ?>