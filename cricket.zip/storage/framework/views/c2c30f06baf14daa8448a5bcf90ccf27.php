

<?php $__env->startSection('title'); ?>
    <?php echo e(optional($company)->name); ?> | About
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<style>
    .about-top-image{
        width: 50%;
        height: auto;
        float: right;
        padding: 10px 20px;
        /* background-color: red */
    }
    .about-top-image img{
        width: 100%;
        height: auto;
        object-fit: contain;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <section class="banner-part sub-main-banner float-start w-100">
        <div class="baner-imghi">
            <img src="<?php echo e(asset('frontend/images/sub-banner01.jpg')); ?>" alt="sub-banner">
        </div>
        <div class="sub-banner">
            <div class="container">
                <h1 class="text-center"> About</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb justify-content-center">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li class="breadcrumb-item-"></li>
                    </ol>
                </nav>
            </div>
        </div>
    </section>

    <div class="about-page-main comon-sub-page-main d-inline-block w-100">
        <div class="about-club-top mt-1 mb-2">
            <div class="container pb-1 pt-0">
                <div class="row row-cols-1 row-cols-lg-2 g-lg-5">
                    

                    <div class="col-12 py-3" style="text-align: justify;">
                        
                        <h2 class="comon-heading m-0 text-center mb-3"> <?php echo e(optional($about)->title); ?> </h2>
                        <div class="about-top-image">
                            <img src="<?php echo e(asset('storage/'.optional($about)->picture)); ?>" alt="pic">
                        </div>
                        
                        <p class="mt-2" style="text-align: justify;">
                           <?php echo optional($about)->about; ?>

                        </p>

                        

                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\cricket\resources\views/frontend/welcome/aboutus.blade.php ENDPATH**/ ?>