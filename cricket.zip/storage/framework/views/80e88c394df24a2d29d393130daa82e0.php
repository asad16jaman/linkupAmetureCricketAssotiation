

<?php $__env->startPush('css'); ?>
    <style>
        .blog-date-badge {
            position: absolute;
            top: 0px;
            right: 15px;
            font-size: 14px;
            font-weight: 600;
            padding: 10px 16px;
            /* border-radius: 6px; */
            line-height: 1.2;
        }

        .blog-date-badge span {
            font-size: 18px;
            font-weight: bold;
            display: block;
        }

        .blog-card {
            transition: all 0.3s ease;
        }

        .blog-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('title'); ?>
     | All Blogs
<?php $__env->stopSection(); ?>



<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <section class="banner-part sub-main-banner float-start w-100">
        <div class="baner-imghi">
            <img src="<?php echo e(asset('frontend/images/sub-banner01.jpg')); ?>" alt="sub-banner">
        </div>
        <div class="sub-banner">
            <div class="container">
                <h1 class="text-center">Blogs</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb justify-content-center">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li class="breadcrumb-item-"></li>
                    </ol>
                </nav>
            </div>
        </div>
    </section>

    <section class="float-start w-100 body-part pt-0">

        <div class="latest-blogs py-3 w3-light-gray">
            <div class="container">
                <div class="row g-4 py-3">
                    <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-lg-3 col-md-6">
                            <a href="<?php echo e(route('welocme.blogs.detial',['uid'=>$blog->uid])); ?>" class="text-decoration-none text-dark">
                                <div class="card border-0 shadow-sm h-100 blog-card">
                                    <div class="position-relative">
                                        <img height="170px" src="<?php echo e(asset('storage/'.$blog->picture)); ?>" class="card-img-top" alt="<?php echo e($blog->name); ?>">
                                        <div class="blog-date-badge bg-danger text-white text-center">
                                            <?php
                                                    $date = \Carbon\Carbon::parse($blog->event_date);
                                                    $dayName = $date->format('D'); 
                                                    $dayNum  = $date->format('d');
                                                    $month   = $date->format('M');
                                                ?>
                                                <?php echo e($dayName); ?> <br><span><?php echo e($dayNum); ?></span><?php echo e($month); ?>

                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <span class="badge bg-danger mb-2 text-uppercase"><?php echo e($blog->eventType->name); ?></span>
                                        <h5 class="card-title fw-semibold w3-medium"><?php echo e($blog->name); ?>

                                        </h5>

                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>There Is No Blogs</p>
                    <?php endif; ?>



                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\cricket\resources\views/frontend/welcome/blogs.blade.php ENDPATH**/ ?>