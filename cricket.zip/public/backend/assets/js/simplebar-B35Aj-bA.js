(function(){var e=document.getElementById("sidebar-scroll");new SimpleBar(e,{autoHide:!0})})();
